document.addEventListener('DOMContentLoaded', function () {
    const currentUser = parseInt(sps_vars.current_user_id || 0);
    let userHasSlot = false;

    function loadSlots() {
        fetch(sps_vars.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=sps_get_slots'
        })
        .then(res => res.json())
        .then(res => {
            if (!res.success) return;
            const slots = res.data;
            userHasSlot = Object.values(slots).some(s => s.user_id == currentUser && (s.status === 'Reserved' || s.status === 'Parked'));

            document.querySelectorAll('.slot').forEach(slot => {
                const slotId = slot.dataset.slotId;
                const data = slots[slotId];
                slot.className = 'slot status-' + data.status;
                slot.querySelector('.status-text').innerHTML = `<strong>${data.status}</strong>`;
                const timerDiv = slot.querySelector('.timer');
                const actionsDiv = slot.querySelector('.actions');
                timerDiv.innerHTML = '';
                actionsDiv.innerHTML = '';
                const left = data.expires_at - Math.floor(Date.now() / 1000);
                if (left > 0) {
                    const mins = Math.floor(left / 60);
                    const secs = left % 60;
                    timerDiv.textContent = `⏳ ${mins}m ${secs}s`;
                }

                if (data.status === 'Free') {
                    if (currentUser !== 0 && !userHasSlot) {
                        actionsDiv.innerHTML = `
                            <button class="reserve-btn" onclick="reserveSlot(${slotId})">Reserve</button>
                            <button class="park-btn" onclick="promptPark(${slotId})">Park</button>`;
                    } else if (userHasSlot) {
                        actionsDiv.innerHTML = `<div>🔒 You already have a slot</div>`;
                    } else {
                        actionsDiv.innerHTML = `<div>Please login to Reserve or Park</div>`;
                    }
                } else if (data.status === 'Reserved') {
                    if (data.user_id == currentUser && currentUser !== 0) {
                        actionsDiv.innerHTML = `
                            <button class="parknow-btn" onclick="promptParkNow(${slotId})">Park Now</button>
                            <div>Reserved by you</div>`;
                    } else {
                        actionsDiv.innerHTML = `<div>Reserved by someone else</div>`;
                    }
                } else if (data.status === 'Parked') {
                    if (data.user_id == currentUser && currentUser !== 0) {
                        actionsDiv.innerHTML = `<div>🚗 You parked here</div>`;
                    } else {
                        actionsDiv.innerHTML = `<div>🚗 Parked</div>`;
                    }
                }
            });
        });
    }

    window.reserveSlot = function (slotId) {
        fetch(sps_vars.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=sps_reserve&slot_id=${slotId}`
        }).then(() => loadSlots());
    };

    window.promptPark = function (slotId) {
        let mins = prompt('Enter duration in minutes:');
        if (!mins || isNaN(mins)) return;
        fetch(sps_vars.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=sps_park&slot_id=${slotId}&duration=${mins}`
        }).then(() => loadSlots());
    };

    window.promptParkNow = function (slotId) {
        let mins = prompt('Enter duration in minutes:');
        if (!mins || isNaN(mins)) return;
        fetch(sps_vars.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=sps_parknow&slot_id=${slotId}&duration=${mins}`
        }).then(() => loadSlots());
    };

    loadSlots();
    setInterval(loadSlots, 1000);
});
