<?php
/*
Plugin Name: Smart Parking System
Description: Real-time smart parking with reserve and park-now functionality. Each user can only park or reserve one slot at a time.
Version: 1.2
Author: Your Name
*/

if (!defined('ABSPATH')) exit;

// Enqueue external JS and CSS
add_action('wp_enqueue_scripts', function () {
    if (is_singular()) {
        wp_enqueue_style('sps-style', plugins_url('sps-style.css', __FILE__));
        wp_enqueue_script('sps-script', plugins_url('sps-script.js', __FILE__), [], false, true);

        wp_localize_script('sps-script', 'sps_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'current_user_id' => get_current_user_id()
        ]);
    }
});

// Shortcode for UI
add_shortcode('smart_parking_system', function () {
    ob_start();
    $slots = get_option('sps_parking_slots');
    if (!$slots) {
        $slots = [];
        for ($i = 1; $i <= 10; $i++) {
            $slots[$i] = ['status' => 'Free', 'user_id' => 0, 'expires_at' => 0];
        }
        update_option('sps_parking_slots', $slots);
    }

    echo '<div id="parking-lot">';
    foreach ($slots as $id => $slot) {
        echo "<div class='slot status-{$slot['status']}' data-slot-id='{$id}'>
                <h3>Slot {$id}</h3>
                <div class='status-text'><strong>{$slot['status']}</strong></div>
                <div class='timer'></div>
                <div class='actions'></div>
              </div>";
    }
    echo '</div>';
    return ob_get_clean();
});

// AJAX handlers
add_action('wp_ajax_sps_get_slots', 'sps_get_slots');
add_action('wp_ajax_nopriv_sps_get_slots', 'sps_get_slots');
function sps_get_slots() {
    $slots = get_option('sps_parking_slots');
    $now = time();
    foreach ($slots as $id => $slot) {
        if ($slot['expires_at'] > 0 && $slot['expires_at'] <= $now) {
            $slots[$id] = ['status' => 'Free', 'user_id' => 0, 'expires_at' => 0];
        }
    }
    update_option('sps_parking_slots', $slots);
    wp_send_json_success($slots);
}

add_action('wp_ajax_sps_reserve', 'sps_reserve');
function sps_reserve() {
    if (!is_user_logged_in()) wp_send_json_error('Login required');
    $uid = get_current_user_id();
    $id = intval($_POST['slot_id']);
    $slots = get_option('sps_parking_slots');

    foreach ($slots as $slot) {
        if ($slot['user_id'] == $uid && ($slot['status'] === 'Reserved' || $slot['status'] === 'Parked')) {
            wp_send_json_error('You already have a slot');
        }
    }

    if (isset($slots[$id]) && $slots[$id]['status'] === 'Free') {
        $slots[$id] = [
            'status' => 'Reserved',
            'user_id' => $uid,
            'expires_at' => time() + 300
        ];
        update_option('sps_parking_slots', $slots);
        wp_send_json_success();
    }

    wp_send_json_error('Slot not free');
}

add_action('wp_ajax_sps_park', 'sps_park');
function sps_park() {
    if (!is_user_logged_in()) wp_send_json_error('Login required');
    $uid = get_current_user_id();
    $id = intval($_POST['slot_id']);
    $mins = intval($_POST['duration']);
    $slots = get_option('sps_parking_slots');

    foreach ($slots as $slot) {
        if ($slot['user_id'] == $uid && ($slot['status'] === 'Reserved' || $slot['status'] === 'Parked')) {
            wp_send_json_error('You already have a slot');
        }
    }

    if (isset($slots[$id]) && $slots[$id]['status'] === 'Free') {
        $slots[$id] = [
            'status' => 'Parked',
            'user_id' => $uid,
            'expires_at' => time() + ($mins * 60)
        ];
        update_option('sps_parking_slots', $slots);
        wp_send_json_success();
    }

    wp_send_json_error('Slot not free');
}

add_action('wp_ajax_sps_parknow', 'sps_parknow');
function sps_parknow() {
    if (!is_user_logged_in()) wp_send_json_error('Login required');
    $uid = get_current_user_id();
    $id = intval($_POST['slot_id']);
    $mins = intval($_POST['duration']);
    $slots = get_option('sps_parking_slots');

    if (isset($slots[$id]) && $slots[$id]['status'] === 'Reserved' && $slots[$id]['user_id'] == $uid) {
        $slots[$id]['status'] = 'Parked';
        $slots[$id]['expires_at'] = time() + ($mins * 60);
        update_option('sps_parking_slots', $slots);
        wp_send_json_success();
    }

    wp_send_json_error('Cannot park now');
}
